function Svg({ size = 20, className = '', children }) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        aria-hidden="true"
      >
        {children}
      </svg>
    )
}

export function RestaurantPlateIcon({ size = 20, className = '', ...props }) {
    return (
        <svg
            width={size}
            height={size}
            viewBox="0 0 512 512"
            fill="currentColor"
            className={className}
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            {...props}
        >
            <path d="M79.117,87.515v68.101c0,7.125-3.145,13.524-8.116,17.897V87.515H39.559v85.997c-4.971-4.372-8.117-10.773-8.117-17.897V87.515H0v68.101c0,25.02,16.713,46.199,39.559,52.989v22.031c4.97-1.545,10.25-2.379,15.721-2.379c5.471,0.001,10.751,0.834,15.721,2.379v-22.032c22.845-6.79,39.558-27.968,39.558-52.989v-68.1H79.117z" />

            <path d="M490.471,103.237c-11.89,0-21.529,9.639-21.529,21.529v92.985c0,5.216,1.856,9.997,4.943,13.723c5.221-1.726,10.794-2.675,16.588-2.675c5.79,0,11.364,0.947,16.586,2.675c3.087-3.726,4.943-8.507,4.943-13.723v-92.985C512,112.876,502.361,103.237,490.471,103.237z" />

            <path d="M55.279,259.699c-11.93,0-21.6,9.67-21.6,21.6v121.585c0,11.93,9.67,21.6,21.6,21.6c11.93,0,21.6-9.67,21.6-21.6V281.3C76.88,269.37,67.209,259.699,55.279,259.699z" />

            <path d="M490.47,260.241c-11.89,0-21.529,9.639-21.529,21.529v121.185c0,11.89,9.639,21.529,21.529,21.529c11.89,0,21.529-9.639,21.529-21.529V281.77C512,269.88,502.36,260.241,490.47,260.241z" />

            <path d="M272.84,157.482c-54.323,0-98.517,44.194-98.517,98.517c0,54.323,44.194,98.517,98.517,98.517s98.517-44.195,98.517-98.517S327.161,157.482,272.84,157.482z" />

            <path d="M440.113,244.637c-0.462-6.878-1.343-13.644-2.614-20.274C422.663,146.987,354.478,88.333,272.84,88.333c-92.451,0-167.667,75.215-167.667,167.666c0,7.81,0.549,15.493,1.588,23.023c0.385,2.792,0.839,5.562,1.36,8.309c14.716,77.528,82.974,136.334,164.718,136.334c82.737,0,151.658-60.24,165.231-139.162c0.07-0.411,0.137-0.824,0.205-1.236c1.459-8.877,2.23-17.984,2.23-27.268C440.506,252.18,440.365,248.394,440.113,244.637z M272.84,385.959c-71.66,0-129.959-58.299-129.959-129.959S201.18,126.04,272.84,126.04s129.959,58.299,129.959,129.959S344.5,385.959,272.84,385.959z" />
        </svg>
    );
}

  //  --------------------------------------------
  // Outils --------------------------------------------
  //  --------------------------------------------
      // Plateaux >>>


// WatermelonIcon
// https://www.svgrepo.com/svg/176520/water-melon-slice

// PeachOpenIcon
// https://www.svgrepo.com/svg/266609/peach

// PeachIcon
// https://www.svgrepo.com/svg/266612/peach

// BreadIcon
// https://www.svgrepo.com/svg/266614/baguette-bread

// RaspberryIcon
// https://www.svgrepo.com/svg/266611/raspberry-blackberry

// OrangeIcon
// https://www.svgrepo.com/svg/266613/orange

// CarrotIcon
// https://www.svgrepo.com/svg/266616/carrot

// SaltIcon
// https://www.svgrepo.com/svg/266628/salt-shaker-salt

// LoafIcon
// https://www.svgrepo.com/svg/266633/bread

// DishIcon
// https://www.svgrepo.com/svg/266635/dish

// ChefIcon
// https://www.svgrepo.com/svg/266652/chef

// LemonIcon
// https://www.svgrepo.com/svg/266673/lemon

// PearIcon
// https://www.svgrepo.com/svg/266677/pear

// IceCreamIcon
// https://www.svgrepo.com/svg/67046/melting-ice-cream

// AcornIcon
// https://www.svgrepo.com/svg/190991/acorn

/*
    FoodIcon
    FoodIcons
    MealIcon
    MealsIcon
    DishIcon
    CuisineIcon
    CookingIcon
    KitchenIcon
    ChefIcon
    CookingPotIcon
    FryingPanIcon
    SaucepanIcon
    WokIcon
    PressureCookerIcon
    SlowCookerIcon
    OvenIcon
    MicrowaveIcon
    StoveIcon
    CooktopIcon
    AirFryerIcon
    ToasterIcon
    BlenderIcon
    MixerIcon
    FoodProcessorIcon
    RefrigeratorIcon
    FreezerIcon
    DishwasherIcon
    KitchenScaleIcon
    CuttingBoardIcon
    KitchenKnifeIcon
    ChefKnifeIcon
    ForkIcon
    SpoonIcon
    TableKnifeIcon
    SpatulaIcon
    WhiskIcon
    LadleIcon
    TongsIcon
    PeelerIcon
    GraterIcon
    RollingPinIcon
    ColanderIcon
    SieveIcon
    MeasuringCupIcon
    MeasuringSpoonIcon
    PlateIcon
    BowlIcon
    ServingDishIcon
    TrayIcon
    FoodContainerIcon
    LunchBoxIcon
    BentoBoxIcon
    TakeawayBoxIcon
    FoodPackagingIcon
    GroceryIcon
    GroceriesIcon
    ShoppingBasketIcon
    ShoppingCartIcon
    SupermarketIcon
    GroceryStoreIcon
    FoodMarketIcon
    FarmersMarketIcon
    FoodDeliveryIcon
    FoodTakeawayIcon
    RestaurantIcon
    CafeIcon
    BakeryIcon
    PizzeriaIcon
    FoodTruckIcon
    StreetFoodIcon
    FastFoodIcon
    HomemadeFoodIcon
    OrganicFoodIcon
    HealthyFoodIcon
    NaturalFoodIcon
    FreshFoodIcon
    FrozenFoodIcon
    CannedFoodIcon
    ProcessedFoodIcon
    VeganFoodIcon
    VegetarianFoodIcon
    PlantBasedFoodIcon
    GlutenFreeFoodIcon
    DairyFreeFoodIcon
    SugarFreeFoodIcon
    LowCarbFoodIcon
    KetoFoodIcon
    HalalFoodIcon
    KosherFoodIcon
    AllergyFriendlyFoodIcon
    FruitIcon
    FruitsIcon
    AppleIcon
    BananaIcon
    OrangeIcon
    LemonIcon
    LimeIcon
    StrawberryIcon
    BlueberryIcon
    RaspberryIcon
    BlackberryIcon
    CherryIcon
    GrapeIcon
    WatermelonIcon
    MelonIcon
    PineappleIcon
    MangoIcon
    PapayaIcon
    KiwiIcon
    PeachIcon
    PearIcon
    PlumIcon
    CoconutIcon
    AvocadoIcon
    PomegranateIcon
    GrapefruitIcon
    FigIcon
    DateFruitIcon
    VegetableIcon
    VegetablesIcon
    CarrotIcon
    PotatoIcon
    SweetPotatoIcon
    TomatoIcon
    CucumberIcon
    LettuceIcon
    SpinachIcon
    BroccoliIcon
    CauliflowerIcon
    CabbageIcon
    KaleIcon
    PepperIcon
    BellPepperIcon
    ChiliPepperIcon
    OnionIcon
    GarlicIcon
    MushroomIcon
    ZucchiniIcon
    EggplantIcon
    PumpkinIcon
    CornIcon
    PeasIcon
    GreenBeansIcon
    AsparagusIcon
    RadishIcon
    BeetrootIcon
    CeleryIcon
    LeekIcon
    ArtichokeIcon
    GingerIcon
    HerbsIcon
    ParsleyIcon
    BasilIcon
    MintIcon
    CorianderIcon
    RosemaryIcon
    ThymeIcon
    GrainIcon
    GrainsIcon
    WheatIcon
    RiceIcon
    BrownRiceIcon
    QuinoaIcon
    OatsIcon
    BarleyIcon
    PastaIcon
    NoodlesIcon
    BreadIcon
    BaguetteIcon
    CroissantIcon
    BagelIcon
    ToastIcon
    SandwichIcon
    BurgerIcon
    CheeseburgerIcon
    HotDogIcon
    PizzaIcon
    PastaDishIcon
    LasagnaIcon
    SushiIcon
    RamenIcon
    DumplingsIcon
    TacosIcon
    BurritoIcon
    QuesadillaIcon
    NachosIcon
    SaladIcon
    CaesarSaladIcon
    SoupIcon
    StewIcon
    CurryIcon
    RiceBowlIcon
    PokeBowlIcon
    FriedRiceIcon
    OmeletteIcon
    PancakesIcon
    WafflesIcon
    CrepeIcon
    ToastedSandwichIcon
    MeatIcon
    BeefIcon
    SteakIcon
    PorkIcon
    ChickenIcon
    TurkeyIcon
    LambIcon
    SausageIcon
    BaconIcon
    HamIcon
    SeafoodIcon
    FishIcon
    SalmonIcon
    TunaIcon
    ShrimpIcon
    PrawnIcon
    CrabIcon
    LobsterIcon
    OysterIcon
    MusselsIcon
    SquidIcon
    OctopusIcon
    EggIcon
    FriedEggIcon
    BoiledEggIcon
    DairyIcon
    MilkIcon
    CheeseIcon
    ButterIcon
    YogurtIcon
    CreamIcon
    IceCreamIcon
    FrozenYogurtIcon
    DessertIcon
    CakeIcon
    CupcakeIcon
    MuffinIcon
    CookieIcon
    BiscuitIcon
    BrownieIcon
    DonutIcon
    DoughnutIcon
    PieIcon
    TartIcon
    PuddingIcon
    CheesecakeIcon
    ChocolateIcon
    CandyIcon
    SweetIcon
    HoneyIcon
    JamIcon
    PeanutButterIcon
    NutsIcon
    AlmondIcon
    WalnutIcon
    CashewIcon
    PeanutIcon
    SeedsIcon
    ChiaSeedsIcon
    FlaxSeedsIcon
    SunflowerSeedsIcon
    PumpkinSeedsIcon
    BeansIcon
    LentilsIcon
    ChickpeasIcon
    TofuIcon
    TempehIcon
    HummusIcon
    OliveOilIcon
    VegetableOilIcon
    VinegarIcon
    SaltIcon
    PepperSpiceIcon
    SpicesIcon
    CinnamonIcon
    TurmericIcon
    PaprikaIcon
    CuminIcon
    FoodRecipeIcon
    RecipeBookIcon
    CookbookIcon
    MealPlanIcon
    MealPrepIcon
    FoodJournalIcon
    FoodDiaryIcon
    NutritionIcon
    NutritionalValueIcon
    CaloriesIcon
    ProteinIcon
    CarbohydratesIcon
    FatIcon
    FiberIcon
    VitaminsIcon
    MineralsIcon
    FoodPyramidIcon
    BalancedDietIcon
    PortionControlIcon
    FoodWasteIcon
    FoodDonationIcon
    FoodBankIcon
    FoodSafetyIcon
    FoodStorageIcon
    ExpirationDateIcon
    FoodAllergyIcon
    FoodLabelIcon
    OrganicCertificationIcon
    FarmToTableIcon
    SustainableFoodIcon
    LocalFoodIcon
    FoodCultureIcon
    WorldCuisineIcon
*/