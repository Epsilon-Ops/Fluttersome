// DeskWorkIcon
// https://www.svgrepo.com/svg/483906/desk-work

// DeskWork2Icon
// https://www.svgrepo.com/svg/483154/desk-work-6