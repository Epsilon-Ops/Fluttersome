// ResidencyIcon
// https://www.svgrepo.com/svg/286122/pollution-co2

// AnchorIcon
// https://www.svgrepo.com/svg/12534/sailor-tattoo

// CastleIcon
// https://www.svgrepo.com/svg/360182/castle-f

// LadderIcon
// https://www.svgrepo.com/svg/247397/ladder

// Ladder2Icon
// https://www.svgrepo.com/svg/203430/ladder

// BrokenLadderIcon
// https://www.svgrepo.com/svg/203434/ladder

/*
    BuildingIcon
    SkyscraperIcon
    OfficeBuildingIcon
    ApartmentBuildingIcon
    ResidentialBuildingIcon
    CommercialBuildingIcon
    IndustrialBuildingIcon
    GovernmentBuildingIcon
    PublicBuildingIcon
    MunicipalBuildingIcon
    TownHallIcon
    CourthouseIcon
    CityHallIcon
    EmbassyIcon
    ConsulateIcon
    ParliamentIcon
    CapitolIcon
    WhiteHouseIcon
    PalaceIcon
    CastleIcon
    MansionIcon
    VillaIcon
    HouseBuildingIcon
    ApartmentIcon
    CondominiumIcon
    DuplexIcon
    PenthouseIcon
    TownhouseIcon
    CottageIcon
    BungalowIcon
    CabinIcon
    FarmhouseIcon
    BarnIcon
    GarageBuildingIcon
    WarehouseIcon
    FactoryIcon
    ManufacturingPlantIcon
    PowerPlantIcon
    NuclearPlantIcon
    WaterTreatmentPlantIcon
    RecyclingPlantIcon
    ResearchFacilityIcon
    LaboratoryBuildingIcon
    HospitalBuildingIcon
    ClinicBuildingIcon
    MedicalCenterIcon
    SchoolBuildingIcon
    UniversityBuildingIcon
    CollegeBuildingIcon
    LibraryBuildingIcon
    MuseumBuildingIcon
    ArtGalleryBuildingIcon
    TheaterBuildingIcon
    CinemaBuildingIcon
    ConcertHallIcon
    StadiumIcon
    ArenaIcon
    SportsCenterIcon
    GymBuildingIcon
    SwimmingPoolBuildingIcon
    HotelBuildingIcon
    MotelIcon
    ResortBuildingIcon
    HostelIcon
    RestaurantBuildingIcon
    CafeBuildingIcon
    ShoppingMallIcon
    ShoppingCenterIcon
    DepartmentStoreIcon
    SupermarketBuildingIcon
    RetailStoreIcon
    BankBuildingIcon
    FinancialCenterIcon
    ChurchBuildingIcon
    CathedralIcon
    MosqueBuildingIcon
    SynagogueBuildingIcon
    TempleBuildingIcon
    MonasteryIcon
    ChapelIcon
    CemeteryBuildingIcon
    FireStationIcon
    PoliceStationIcon
    PrisonBuildingIcon
    MilitaryBaseIcon
    BarracksIcon
    AirportTerminalIcon
    TrainStationBuildingIcon
    BusStationBuildingIcon
    SubwayStationIcon
    PortBuildingIcon
    LighthouseIcon
    BridgeIcon
    TunnelIcon
    TowerIcon
    ClockTowerIcon
    WaterTowerIcon
    RadioTowerIcon
    TelecommunicationsTowerIcon
    ObservationTowerIcon
    BellTowerIcon
    MonumentIcon
    MemorialIcon
    ArchIcon
    FountainIcon
    GazeboIcon
    PavilionIcon
    GreenhouseIcon
    ConservatoryIcon
    SiloIcon
    HangarIcon
    ParkingBuildingIcon
    ParkingGarageBuildingIcon
    DataCenterIcon
    ServerFacilityIcon
    SmartBuildingIcon
    SustainableBuildingIcon
    GreenBuildingIcon
    EcoBuildingIcon
    PassiveHouseIcon
    BuildingBlueprintIcon
    BuildingPlanIcon
    FloorPlanIcon
    BuildingConstructionIcon
    BuildingRenovationIcon
    BuildingDemolitionIcon
    BuildingMaintenanceIcon
    BuildingInspectionIcon
    BuildingPermitIcon
    BuildingCodeIcon
    BuildingFoundationIcon
    BuildingFacadeIcon
    BuildingRoofIcon
    BuildingEntranceIcon
    BuildingExitIcon
    BuildingFloorIcon
    BuildingElevatorIcon
    BuildingStairsIcon
    BuildingWindowIcon
    BuildingDoorIcon
    BuildingColumnIcon
    BuildingPillarIcon
    BuildingWallIcon
    BuildingBalconyIcon
    BuildingTerraceIcon
    BuildingBasementIcon
    BuildingAtticIcon
    BuildingChimneyIcon
    BuildingAirConditioningIcon
    BuildingHeatingIcon
    BuildingVentilationIcon
    BuildingSecurityIcon
    BuildingAccessIcon
    BuildingFireSafetyIcon
    BuildingAlarmIcon
    BuildingSurveillanceIcon
*/