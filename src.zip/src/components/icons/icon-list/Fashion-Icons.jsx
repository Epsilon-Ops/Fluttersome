function Svg({ size = 20, className = '', children }) {
    return (
      <svg
        width={size}
        height={size}
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
        className={className}
        aria-hidden="true"
      >
        {children}
      </svg>
    )
}


export function CombIcon({ size = 20, className = '', ...props }) {
    return (
        <svg
            width={size}
            height={size}
            viewBox="0 0 297.005 297.005"
            fill="currentColor"
            className={className}
            xmlns="http://www.w3.org/2000/svg"
            aria-hidden="true"
            {...props}
        >
            <path d="M216.504,2.919c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.204,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.86,0.86-2.254,0.86-3.114,0l-33.151-33.15c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.413,0.413-0.973,0.645-1.557,0.645c-0.584,0-1.144-0.232-1.557-0.645l-33.151-33.15c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.86,0.86-2.254,0.86-3.114,0l-33.151-33.15c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.15c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.413,0.413-0.973,0.645-1.557,0.645s-1.144-0.232-1.557-0.645l-33.151-33.151c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.413,0.413-0.973,0.645-1.557,0.645c-0.584,0-1.144-0.232-1.557-0.645l-33.151-33.151c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.86,0.86-2.254,0.86-3.114,0l-33.151-33.15c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.86,0.86-2.254,0.86-3.114,0l-33.15-33.15c-3.893-3.891-10.203-3.891-14.096,0c-3.892,3.892-3.892,10.204,0,14.096l33.151,33.151c0.86,0.86,0.86,2.254,0,3.114l-7.726,7.726c-0.413,0.413-0.973,0.645-1.557,0.645c-0.584,0-1.144-0.232-1.557-0.645l-33.15-33.15c-3.893-3.891-10.202-3.891-14.096,0c-3.892,3.892-3.892,10.203,0,14.096L80.5,294.086c1.87,1.869,4.404,2.919,7.048,2.919s5.179-1.05,7.048-2.919L294.083,94.592c3.892-3.892,3.892-10.203,0-14.096L216.504,2.919z" />
        </svg>
    );
}

// ClothingIcon
// https://www.svgrepo.com/svg/275006/shirt-clothes

// HangerIcon
// https://www.svgrepo.com/svg/455891/clothing-hanger

// ClothTieIcon
// https://www.svgrepo.com/svg/226843/clothing-tie

// ClothBoxerIcon
// https://www.svgrepo.com/svg/261436/clothing-summer

// ShirtStarIcon
// https://www.svgrepo.com/svg/221755/clothing-uniform

// SkirtIcon
// https://www.svgrepo.com/svg/482599/skirt-2

// TagIcon
// https://www.svgrepo.com/svg/477339/tag-6

// ShirtIcon
// https://www.svgrepo.com/svg/236923/shirt

// ShirtSaleIcon
// https://www.svgrepo.com/svg/222722/shirt-style

// ShirtLinedIcon
// https://www.svgrepo.com/svg/113025/shirt

// ShirtSkinnyIcon
// https://www.svgrepo.com/svg/114356/shirt

// PantsIcon
// https://www.svgrepo.com/svg/535551/pants

// PantsJeansIcon
// https://www.svgrepo.com/svg/295290/jeans-pants

// PantsSquaredIcon
// https://www.svgrepo.com/svg/232597/jeans-pants

// UnderpantsIcon
// https://www.svgrepo.com/svg/482593/pants-3

// UnderwearIcon
// https://www.svgrepo.com/svg/275048/underwear-pants

// ClothShortIcon
// https://www.svgrepo.com/svg/290827/shorts-pants

// ClothShort2Icon
// https://www.svgrepo.com/svg/426725/man-fashion-clothes

// DressIcon
// https://www.svgrepo.com/svg/482647/fashion

// FashionTagIcon
// https://www.svgrepo.com/svg/453419/style

// FashionLookIcon
// https://www.svgrepo.com/svg/411962/look

// FashionTrendIcon
// https://www.svgrepo.com/svg/412107/trend

// FashionTendancyIcon
// https://www.svgrepo.com/svg/412524/trend

// FashionStarCollarIcon
// https://www.svgrepo.com/svg/426728/woman-fashion-clothes

// FashionStyleIcon
// https://www.svgrepo.com/svg/315799/style

// FashionPoorOutfitIcon
// https://www.svgrepo.com/svg/380347/clothes-fashion-homeless-poverty-tshirt

// NecktieIcon
// https://www.svgrepo.com/svg/368288/necktie

// ShortScissorsIcon
// https://www.svgrepo.com/svg/374834/cut

// ClothSetIcon
// https://www.svgrepo.com/svg/322052/clothes

// ClothSet2Icon
// https://www.svgrepo.com/svg/308773/outfit-clothes

// ClothStoreIcon
// https://www.svgrepo.com/svg/308575/fashion-boutique-store-boutique-fashion-store

// HandbagIcon
// https://www.svgrepo.com/svg/302294/hand-bag

// DandyIcon
// https://www.svgrepo.com/svg/290461/trendy

// SneakersIcon
// https://www.svgrepo.com/svg/283743/sneakers-shoes

// MannequinIcon
// https://www.svgrepo.com/svg/301826/mannequin

// HatIcon
// https://www.svgrepo.com/svg/482495/hat-hat

// HatFunIcon
// https://www.svgrepo.com/svg/243508/hat-fun

// HatCowboyIcon
// https://www.svgrepo.com/svg/236953/hat-accesory

// HatSheriffIcon
// https://www.svgrepo.com/svg/232643/hat-fedora

// HatFlatIcon
// https://www.svgrepo.com/svg/220354/hat

// HatKittyIcon
// https://www.svgrepo.com/svg/220362/hat

// HatChefIcon
// https://www.svgrepo.com/svg/166148/hat-for-a-chef

// HatMustacheIcon
// https://www.svgrepo.com/svg/79359/hat-with-moustache

// MustacheIcon
// https://www.svgrepo.com/svg/482492/mustache


/*
    FashionIcon
    ClothingIcon
    ApparelIcon
        ++ OutfitIcon
    StyleIcon
    FashionStyleIcon
    FashionDesignIcon
    FashionCollectionIcon
    FashionTrendIcon
    FashionWeekIcon
    RunwayIcon
    CatwalkIcon
    ModelIcon
    FashionModelIcon
    MannequinIcon
    DressIcon
    EveningDressIcon
    WeddingDressIcon
    SkirtIcon
    MiniSkirtIcon
    PantsIcon
    JeansIcon
    TrousersIcon
    ShortsIcon
    LeggingsIcon
    ShirtIcon
    TShirtIcon
    PoloShirtIcon
    BlouseIcon
    TopIcon
    CropTopIcon
    SweaterIcon
    HoodieIcon
    SweatshirtIcon
    CardiganIcon
    JacketIcon
    LeatherJacketIcon
    CoatIcon
    TrenchCoatIcon
    BlazerIcon
    SuitIcon
    TuxedoIcon
    VestIcon
    UniformIcon
    TracksuitIcon
    SportswearIcon
    ActivewearIcon
    SwimwearIcon
    BikiniIcon
    SwimsuitIcon
    UnderwearIcon
    LingerieIcon
    SocksIcon
    StockingsIcon
    ShoesIcon
    SneakersIcon
    TrainersIcon
    BootsIcon
    AnkleBootsIcon
    HighHeelsIcon
    SandalsIcon
    FlipFlopsIcon
    LoafersIcon
    FlatsIcon
    SlippersIcon
    HatIcon
    CapIcon
    BeanieIcon
    FedoraIcon
    BeretIcon
    ScarfIcon
    GlovesIcon
    BeltIcon
    TieIcon
    BowTieIcon
    PocketSquareIcon
    HandbagIcon
    BagIcon
    BackpackIcon
    ToteBagIcon
    ShoulderBagIcon
    CrossbodyBagIcon
    ClutchBagIcon
    WalletIcon
    PurseIcon
    SunglassesIcon
    GlassesIcon
    WatchIcon
    JewelryIcon
    NecklaceIcon
    BraceletIcon
    RingIcon
    EarringsIcon
    PendantIcon
    BroochIcon
    AnkletIcon
    HairAccessoryIcon
    HairClipIcon
    HeadbandIcon
    HairbandIcon
    FashionAccessoriesIcon
    FashionJewelryIcon
    LuxuryFashionIcon
    StreetwearIcon
    VintageFashionIcon
    RetroStyleIcon
    CasualWearIcon
    FormalWearIcon
    BusinessWearIcon
    MinimalistFashionIcon
    SustainableFashionIcon
    EcoFashionIcon
    EthicalFashionIcon
    HauteCoutureIcon
    FastFashionIcon
    SlowFashionIcon
    FashionRetailIcon
    ClothingStoreIcon
    BoutiqueIcon
    FashionBrandIcon
    FashionLabelIcon
    FashionMagazineIcon
    FashionPhotographyIcon
    FashionIllustrationIcon
    FashionSketchIcon
    FashionPortfolioIcon
    FashionShowIcon
    FashionEventIcon
    FashionStylistIcon
    PersonalStylistIcon
    PersonalShoppingIcon
    WardrobeIcon
    ClosetIcon
    CapsuleWardrobeIcon
    OutfitPlanningIcon
    ColorMatchingIcon
    SizeGuideIcon
    MeasurementIcon
    SewingIcon
    SewingMachineIcon
    NeedleIcon
    ThreadIcon
    FabricIcon
    TextileIcon
    PatternMakingIcon
    EmbroideryIcon
    KnittingIcon
    CrochetIcon
    WeavingIcon
    TailoringIcon
    AlterationsIcon
    DressmakingIcon
    FashionManufacturingIcon
    ClothingProductionIcon
    ClothingRepairIcon
    ClothingRecycleIcon
    ThriftFashionIcon
    SecondHandFashionIcon
    ClothesDonationIcon
    LaundryIcon
    IroningIcon
    DryCleaningIcon
    FashionShoppingIcon
    ShoppingBagIcon
    ShoppingCartIcon
    PriceTagIcon
    ClothingTagIcon
    HangerIcon
    ClothesRackIcon
    DressingRoomIcon
    FittingRoomIcon
    FashionMirrorIcon
*/

/*
    ClothingIcon
    ShirtIcon
    TShirtIcon
    PoloShirtIcon
    TankTopIcon
    CropTopIcon
    BlouseIcon
    DressShirtIcon
    SweaterIcon
    JumperIcon
    HoodieIcon
    SweatshirtIcon
    CardiganIcon
    VestIcon
    WaistcoatIcon
    JacketIcon
    CoatIcon
    TrenchCoatIcon
    RaincoatIcon
    OvercoatIcon
    PeacoatIcon
    ParkaIcon
    PufferJacketIcon
    LeatherJacketIcon
    DenimJacketIcon
    WindbreakerIcon
    BlazerIcon
    SuitIcon
    TuxedoIcon
    FormalWearIcon
    CasualWearIcon
    SportswearIcon
    ActivewearIcon
    WorkwearIcon
    UniformIcon
    ScrubsIcon
    LabCoatIcon
    ApronIcon
    CoverallsIcon
    OverallsIcon
    JumpsuitIcon
    RomperIcon
    DressIcon
    EveningDressIcon
    WeddingDressIcon
    CocktailDressIcon
    MaxiDressIcon
    MiniDressIcon
    MidiDressIcon
    SundressIcon
    ShirtDressIcon
    SweaterDressIcon
    SkirtIcon
    MiniSkirtIcon
    MidiSkirtIcon
    MaxiSkirtIcon
    PencilSkirtIcon
    PleatedSkirtIcon
    JeansIcon
    DenimIcon
    PantsIcon
    TrousersIcon
    ChinosIcon
    CargoPantsIcon
    LeggingsIcon
    JoggersIcon
    SweatpantsIcon
    ShortsIcon
    BermudaShortsIcon
    BoardshortsIcon
    CapriPantsIcon
    CulottesIcon
    TracksuitIcon
    TracksuitPantsIcon
    SuitPantsIcon
    UnderwearIcon
    UnderpantsIcon
    BriefsIcon
    BoxersIcon
    BoxerShortsIcon
    PantiesIcon
    BraIcon
    SportsBraIcon
    LingerieIcon
    CorsetIcon
    BodysuitIcon
    ShapewearIcon
    NightwearIcon
    PajamasIcon
    NightgownIcon
    RobeIcon
    BathrobeIcon
    SlippersIcon
    SocksIcon
    AnkleSocksIcon
    KneeHighSocksIcon
    StockingsIcon
    TightsIcon
    PantyhoseIcon
    LegWarmersIcon
    GlovesIcon
    MittensIcon
    WinterGlovesIcon
    ScarfIcon
    NeckScarfIcon
    ShawlIcon
    StoleIcon
    HatIcon
    CapIcon
    BaseballCapIcon
    BeanieIcon
    WoolHatIcon
    BucketHatIcon
    SunHatIcon
    FedoraIcon
    BeretIcon
    CowboyHatIcon
    TopHatIcon
    BowlerHatIcon
    PanamaHatIcon
    VisorIcon
    HeadbandIcon
    BandanaIcon
    TurbanIcon
    HijabIcon
    VeilIcon
    HelmetIcon
    BikeHelmetIcon
    SkiHelmetIcon
    ShoesIcon
    ShoeIcon
    SneakersIcon
    RunningShoesIcon
    TrainersIcon
    BootsIcon
    AnkleBootsIcon
    KneeHighBootsIcon
    CowboyBootsIcon
    HikingBootsIcon
    WorkBootsIcon
    RainBootsIcon
    SandalsIcon
    FlipFlopsIcon
    SlidesIcon
    SlippersIcon
    HeelsIcon
    HighHeelsIcon
    StilettosIcon
    PumpsIcon
    WedgesIcon
    FlatsIcon
    BalletFlatsIcon
    LoafersIcon
    MoccasinsIcon
    OxfordsIcon
    BroguesIcon
    DerbyShoesIcon
    DressShoesIcon
    EspadrillesIcon
    ClogsIcon
    MaryJanesIcon
    PlatformShoesIcon
    SkateShoesIcon
    CleatsIcon
    FootballBootsIcon
    SoccerCleatsIcon
    BasketballShoesIcon
    TennisShoesIcon
    GolfShoesIcon
    SkiBootsIcon
    SnowboardBootsIcon
    AccessoriesIcon
    BeltIcon
    LeatherBeltIcon
    SuspendersIcon
    TieIcon
    BowTieIcon
    NecktieIcon
    PocketSquareIcon
    CufflinksIcon
    WatchIcon
    WristwatchIcon
    SunglassesIcon
    GlassesIcon
    EyeglassesIcon
    ReadingGlassesIcon
    FashionGlassesIcon
    HandbagIcon
    ShoulderBagIcon
    ToteBagIcon
    CrossbodyBagIcon
    ClutchBagIcon
    BackpackIcon
    SchoolBagIcon
    MessengerBagIcon
    DuffelBagIcon
    TravelBagIcon
    WalletIcon
    PurseIcon
    CoinPurseIcon
    CardHolderIcon
    KeychainIcon
    UmbrellaIcon
    FashionJewelryIcon
    NecklaceIcon
    PendantIcon
    BraceletIcon
    BangleIcon
    AnkletIcon
    RingIcon
    EarringsIcon
    StudEarringsIcon
    HoopEarringsIcon
    BroochIcon
    HairClipIcon
    HairPinIcon
    HairTieIcon
    ScrunchieIcon
    HairBandIcon
    HairAccessoryIcon
    ClothingTagIcon
    PriceTagIcon
    SizeTagIcon
    HangerIcon
    ClothesHangerIcon
    CoatHangerIcon
    WardrobeIcon
    ClosetIcon
    LaundryIcon
    LaundryBasketIcon
    WashingMachineIcon
    IronIcon
    IroningBoardIcon
    SewingMachineIcon
    NeedleIcon
    ThreadIcon
    ButtonIcon
    ZipperIcon
    SafetyPinIcon
    FabricIcon
    TextileIcon
    CottonIcon
    WoolIcon
    SilkIcon
    LeatherIcon
    DenimFabricIcon
    PatternIcon
    SewingKitIcon
    MeasuringTapeIcon
    DressmakingIcon
    TailoringIcon
    FashionDesignIcon
    FashionSketchIcon
    MannequinIcon
    DressFormIcon
    ClothingStoreIcon
    FashionStoreIcon
    BoutiqueIcon
    FashionCollectionIcon
    FashionShowIcon
    RunwayIcon
    ModelIcon
    OutfitIcon
    OutfitSetIcon
    WardrobeCollectionIcon
    SustainableFashionIcon
    RecycledClothingIcon
    VintageClothingIcon
    SecondHandClothingIcon
    ThriftStoreIcon
    ClothingDonationIcon
    ClothesRecyclingIcon
    LaundryDetergentIcon
    FabricSoftenerIcon
    DryCleaningIcon
    ClothesDryingIcon
    FoldingClothesIcon
    IronedClothesIcon
*/