import {
  ArrowUpIcon,
  ArrowRightIcon,
  ArrowDownRightIcon,
  ArrowDownIcon,
  ArrowDownLeftIcon,
  ArrowLeftIcon,
  ArrowUpLeftIcon,

  ArrowUpNarrowIcon,
  ArrowUpRightNarrowIcon,
  ArrowRightNarrowIcon,
  ArrowDownRightNarrowIcon,
  ArrowDownNarrowIcon,
  ArrowDownLeftNarrowIcon,
  ArrowLeftNarrowIcon,
  ArrowUpLeftNarrowIcon,
} from '../icon-list/Arrow-Icons'

import {
    SmileIcon,
    MoonIcon,
    HeartIcon,
} from '../icon-list/Emotion-Icons'
  
  import {
    LeafIcon,
    SunIcon,
    TwinBranchIcon,
  } from '../icon-list/Nature-Icons'

  import {
    CombIcon,
  } from '../icon-list/Fashion-Icons'
  
  import {
    TrophyIcon,
    ActivityIcon,
    DumbbellIcon,
  } from '../icon-list/Sport-Icons'
  
  import {
    DashboardIcon,
    CheckIcon,
    SparklesIcon,
    ArrowUpRightIcon,
    InfoIcon,
  } from '../icon-list/Interface-Icons'

  import {
    GhostIcon,
    WitchHatIcon,
    EasterEggIcon,
  } from '../icon-list/Celebration-Icons'

  import {
    EggIcon,
  } from '../icon-list/Animal-Icons'

  import {
    Money1Icon,
    Money2Icon,
    DollarIcon,
    MoneyCardIcon,
    MastercardCardIcon,
    CardLayoutIcon,
    DoubleCardIcon,
    DoubleCoinIcon,
    CloverCoinIcon,
  } from '../icon-list/Finance-Icons'

  import {
    HomeIcon,
    DoorIcon,
    KeyIcon,

    SofaShortIcon,
    SofaLongIcon,
    TVIcon,

    BedIcon,
    BedSleepingIcon,
    BedroomTableIcon,
    BedroomLampIcon,

    MirrorIcon,
    MirrorMakeupIcon,
    MirrorBedroomIcon,
    MirrorPlateIcon,

    LightbulbIcon,
    LightbulbPowerIcon,

    BathIcon,
    ToiletPaperIcon,
    ToiletIcon,

    SinkIcon,
    SafeboxIcon,
    FireplaceIcon,
  } from '../icon-list/Home-Icons'

  import {
    ToothpasteNBrushIcon,
    ToothIcon,
  } from '../icon-list/Health-Icons'

  import {
    RestaurantPlateIcon,
  } from '../icon-list/Food-Icons'
  
  export const iconMap = {
    // ----------------------------------------------------------
    // Flèches ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Flèches classiques
    arrow_up: ArrowUpIcon,
    arrow_up_right: ArrowUpRightIcon,
    arrow_right: ArrowRightIcon,
    arrow_down_right: ArrowDownRightIcon,
    arrow_down: ArrowDownIcon,
    arrow_down_left: ArrowDownLeftIcon,
    arrow_left: ArrowLeftIcon,
    arrow_up_left: ArrowUpLeftIcon,

        // >>> Flèches maigres
    arrow_up_narrow: ArrowUpNarrowIcon,
    arrow_up_right_narrow: ArrowUpRightNarrowIcon,
    arrow_right_narrow: ArrowRightNarrowIcon,
    arrow_down_right_narrow: ArrowDownRightNarrowIcon,
    arrow_down_narrow: ArrowDownNarrowIcon,
    arrow_down_left_narrow: ArrowDownLeftNarrowIcon,
    arrow_left_narrow: ArrowLeftNarrowIcon,
    arrow_up_left_narrow: ArrowUpLeftNarrowIcon,

    // ----------------------------------------------------------
    // Maison ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Maison Simple
    home: HomeIcon,
    door: DoorIcon,
    key: KeyIcon,

        // >>> Salon
    sofa_short: SofaShortIcon,
    sofa_long: SofaLongIcon,
    tv: TVIcon,
    fireplace: FireplaceIcon,

        // >>> Chambre
    bed: BedIcon,
    sleeping_in_bed: BedSleepingIcon,
    bedroom_table: BedroomTableIcon,
    bedroom_lamp: BedroomLampIcon,
    safebox: SafeboxIcon,

        // >>> Mirroirs
    mirror: MirrorIcon,
    mirror_makeup: MirrorMakeupIcon,
    mirror_bedroom: MirrorBedroomIcon,
    mirror_plate: MirrorPlateIcon,

        // >>> Electricité
    lightbulb: LightbulbIcon,
    lightbulb_power: LightbulbPowerIcon,

        // >>> Bain
    bath: BathIcon,
    key_i: KeyIcon,
    toothpaste_n_brush: ToothpasteNBrushIcon,
    toilet_paper: ToiletPaperIcon,
    toilet: ToiletIcon,

        // >>> Cuisine
    sink: SinkIcon,

    dashboard: DashboardIcon,
    trophy: TrophyIcon,
    activity: ActivityIcon,
    dumbbell: DumbbellIcon,
    smile: SmileIcon,
    moon: MoonIcon,
    heart: HeartIcon,
    leaf: LeafIcon,
    sun: SunIcon,
    check: CheckIcon,
    sparkles: SparklesIcon,
    info: InfoIcon,

    // ----------------------------------------------------------
    // Santé ----------------------------------------------------------
    // ----------------------------------------------------------
    tooth: ToothIcon,

    // ----------------------------------------------------------
    // Animaux ----------------------------------------------------------
    // ----------------------------------------------------------
    egg: EggIcon,

    // ----------------------------------------------------------
    // Nouriturre ----------------------------------------------------------
    // ----------------------------------------------------------
    restaurant_plate: RestaurantPlateIcon,

    // ----------------------------------------------------------
    // Célébrations ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Halloween
    ghost: GhostIcon,
    witch_hat: WitchHatIcon,
    easter_egg: EasterEggIcon,

    // ----------------------------------------------------------
    // Finance ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Monnaie
    money_i: Money1Icon,
    money_ii: Money2Icon,
    dollar: DollarIcon,

        // >>> Cartes
    money_card: MoneyCardIcon,
    mastercard_card: MastercardCardIcon,
    card_layout: CardLayoutIcon,
    double_card: DoubleCardIcon,

        // >>> Pièces
    double_coin: DoubleCoinIcon,
    clover_coin: CloverCoinIcon,

    // ----------------------------------------------------------
    // Nature ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Végétal
    twin_branch: TwinBranchIcon,

    // ----------------------------------------------------------
    // Fashion ----------------------------------------------------------
    // ----------------------------------------------------------
        // >>> Cheveux
    comb: CombIcon,
  }
  
  export function AppIcon({
    name,
    size = 20,
    className = '',
    strokeWidth,
  }) {
    const Icon = iconMap[name] ?? DashboardIcon
  
    return (
      <Icon
        size={size}
        className={className}
        {...(strokeWidth != null ? { strokeWidth } : {})}
      />
    )
  }